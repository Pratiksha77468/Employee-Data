package com.emp;

import java.util.ArrayList;

public class EmployeeClient {
	public static void main(String[] args) throws Exception {
		ArrayList<Employee> alemp = EmployeeController.empControll();
				for (Employee employee : alemp) {
			System.out.println(employee.eid);
			System.out.println(employee.ename);
			System.out.println(employee.eaddress);
			
		}
				
	}
	

}
