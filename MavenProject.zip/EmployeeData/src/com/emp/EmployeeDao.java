package com.emp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class EmployeeDao {
	static ArrayList<Employee> empDao() throws Exception{
		//1.load the driver
		Class.forName("com.mysql.jdbc.Driver");
		//2. Create Connection
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "pradip");
		//3 write query
		String sql = "select * from employee";
		//4.preapre statement
		Statement statement = connection.createStatement();
		//5.execute query using resultset
		ResultSet resultSet = statement.executeQuery(sql);
		
		ArrayList<Employee> alEmp = new ArrayList<Employee>();
		while(resultSet.next()) {
			int eid = resultSet.getInt(1);
			String ename = resultSet.getString(2);
			String eaddress = resultSet.getString(3);
			Employee emp = new Employee(eid,ename,eaddress);
			System.out.println("eid = "+ eid);
			System.out.println("ename = "+ ename);
			System.out.println("eaddress = "+ eaddress);
			
			alEmp.add(emp);
			
			}
		System.out.println("***********");
		return alEmp;
	}

}
