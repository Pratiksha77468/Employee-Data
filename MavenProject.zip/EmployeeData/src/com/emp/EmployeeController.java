package com.emp;

import java.util.ArrayList;

public class EmployeeController {
	static ArrayList<Employee> empControll() throws Exception{
	
	ArrayList<Employee> alemp = EmployeeService.empService();
	return alemp;
	}
}
