package com.emp;

import java.util.ArrayList;

public class EmployeeService {
	static ArrayList<Employee> empService() throws Exception{
		ArrayList<Employee> alemp = EmployeeDao.empDao();
		
		ArrayList<Employee> all =new ArrayList<Employee>();
		for (Employee employee2 : alemp) {
			if(employee2.ename.endsWith("p")) {
				all.add(employee2);
			}
		}
		return all;
	}

}
